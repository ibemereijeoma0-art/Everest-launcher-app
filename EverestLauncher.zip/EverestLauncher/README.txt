EVEREST LAUNCHER - Android Studio project

BUILD
1. Install Android Studio (Koala or newer). File > Open > select this folder.
2. Let Gradle sync (needs internet the first time).
3. Plug in a phone (USB debugging on) and press Run, or Build > Build APK(s).
   The APK is at app/build/outputs/apk/debug/app-debug.apk

SET AS HOME
After installing, press the Home button and choose "Everest Launcher" > Always.

OFFLINE 3D (optional)
The 3D wallpapers load three.js from the internet. To work fully offline, download
https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js
and save it as app/src/main/assets/three.min.js

CUSTOMISE
- UI and wallpapers: app/src/main/assets/index.html
- Native code (app list, launching, file picker): MainActivity.kt
- Icon: your image is already resized into app/src/main/res/mipmap-*

BUILD WITH GITHUB (no Android Studio needed)
1. Create a new GitHub repository and upload ALL files of this folder
   (including the hidden .github folder) to the main branch.
2. Open the Actions tab > "Build APK" > wait for the green tick (about 5 minutes).
   You can also press "Run workflow" to start it manually.
3. Open the finished run, scroll to Artifacts, download "EverestLauncher-apk",
   unzip it and install app-debug.apk on your phone.
